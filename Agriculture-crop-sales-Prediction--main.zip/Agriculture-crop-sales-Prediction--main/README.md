Use python Version 3.8 to execute the code
